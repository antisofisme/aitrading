import sqlalchemy

SQLALCHEMY_VERSION = sqlalchemy.__version__.split(".")
